# Kasir Sayuran Android

Proyek Android native untuk kasir sayuran berbasis berat.

Fitur awal:
- Scan barcode kamera
- Cari produk berdasarkan barcode
- Harga per kg dan hitung subtotal dari gram
- Keranjang transaksi
- Pembayaran dan kembalian
- Database lokal Room/offline
- Riwayat transaksi

## Build menjadi APK
1. Buka folder ini di Android Studio terbaru.
2. Tunggu Gradle Sync selesai dan izinkan Android Studio mengunduh dependency.
3. Pilih **Build > Build APK(s)**.
4. APK debug akan berada di `app/build/outputs/apk/debug/app-debug.apk`.
5. Ganti nama menjadi `KasirSayuran.apk` bila diperlukan.

Catatan: database stok dan pengelolaan produk masih menjadi dasar versi 1; UI dapat diperluas untuk menu master barang/stok dan laporan detail.
