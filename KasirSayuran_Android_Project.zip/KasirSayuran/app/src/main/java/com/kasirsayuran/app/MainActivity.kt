package com.kasirsayuran.app

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var db: AppDb
    private val cart = mutableListOf<CartItem>()
    private val rupiah = NumberFormat.getCurrencyInstance(Locale("id","ID"))
    private lateinit var list: LinearLayout
    private lateinit var totalView: TextView
    override fun onCreate(b: Bundle?) { super.onCreate(b); db=AppDb.get(this); showCashier() }
    private fun money(v: Double)=rupiah.format(v).replace(",00","")
    private fun showCashier(){
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL; setPadding(20,18,20,12)}
        val title=TextView(this).apply{text="🥬 Kasir Sayuran";textSize=26f;setTextColor(0xff1b5e20.toInt());setPadding(0,0,0,14)}
        root.addView(title)
        val scan=Button(this).apply{text="📷  SCAN BARCODE";setOnClickListener{startActivityForResult(Intent(this@MainActivity,ScannerActivity::class.java),99)}}
        root.addView(scan)
        val manual=Button(this).apply{text="＋ Tambah Barang Manual";setOnClickListener{addManual()}};root.addView(manual)
        list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}; root.addView(ScrollView(this).apply{addView(list)},LinearLayout.LayoutParams(-1,0,1f))
        totalView=TextView(this).apply{textSize=21f;setPadding(0,12,0,12);setTextColor(0xff1b5e20.toInt())};root.addView(totalView)
        val pay=Button(this).apply{text="💵 BAYAR";setOnClickListener{pay()}};root.addView(pay)
        val history=Button(this).apply{text="📚 Riwayat & Stok";setOnClickListener{showHistory()}};root.addView(history)
        setContentView(root); refresh()
    }
    private fun addManual(){ val name=EditText(this).apply{hint="Nama barang"}; val price=EditText(this).apply{hint="Harga/kg";inputType=2}; val weight=EditText(this).apply{hint="Berat (gram)";inputType=2}; LinearLayout(this).also{it.orientation=LinearLayout.VERTICAL;it.addView(name);it.addView(price);it.addView(weight); AlertDialog.Builder(this).setTitle("Tambah ke keranjang").setView(it).setPositiveButton("Tambah"){_,_-> addCart(name.text.toString(),price.text.toString().toDoubleOrNull()?:0.0,weight.text.toString().toDoubleOrNull()?:0.0,"")}.setNegativeButton("Batal",null).show()} }
    private fun addCart(n:String,p:Double,g:Double,code:String){if(n.isBlank()||p<=0||g<=0)return;cart.add(CartItem(n,p,g,code));refresh()}
    private fun refresh(){list.removeAllViews();var t=0.0;cart.forEachIndexed{idx,x->val sub=x.priceKg*x.grams/1000;t+=sub;val tv=TextView(this).apply{text="${x.name} • ${x.grams.toInt()} g • ${money(sub)}";textSize=17f;setPadding(0,10,0,10);setOnLongClickListener{cart.removeAt(idx);refresh();true}};list.addView(tv)};totalView.text="TOTAL  ${money(t)}\n(Tahan item untuk hapus)"}
    override fun onActivityResult(r:Int,c:Int,d:android.content.Intent?){super.onActivityResult(r,c,d);if(r==99&&c==RESULT_OK){val code=d?.getStringExtra("barcode")?:return; lookup(code)}}
    private fun lookup(code:String){ lifecycleScope.launch{val p=db.productDao().byBarcode(code); if(p==null){addManual()}else{val w=EditText(this@MainActivity).apply{hint="Berat gram";inputType=2};AlertDialog.Builder(this@MainActivity).setTitle(p.name).setMessage("Harga ${money(p.priceKg)}/kg").setView(w).setPositiveButton("Tambah"){_,_->addCart(p.name,p.priceKg,w.text.toString().toDoubleOrNull()?:0.0,code)}.setNegativeButton("Batal",null).show()}}}
    private fun pay(){if(cart.isEmpty())return;var total=0.0;cart.forEach{total+=it.priceKg*it.grams/1000};val input=EditText(this).apply{hint="Uang diterima";inputType=2};AlertDialog.Builder(this).setTitle("Pembayaran ${money(total)}").setView(input).setPositiveButton("Simpan"){_,_->val cash=input.text.toString().toDoubleOrNull()?:0.0;if(cash>=total){lifecycleScope.launch{db.saleDao().insert(Sale(0,System.currentTimeMillis(),total));cart.clear();refresh();Toast.makeText(this@MainActivity,"Kembalian ${money(cash-total)}",Toast.LENGTH_LONG).show()}}}}.setNegativeButton("Batal",null).show()}
    private fun showHistory(){lifecycleScope.launch{val sales=db.saleDao().all();AlertDialog.Builder(this@MainActivity).setTitle("Riwayat Transaksi").setMessage(if(sales.isEmpty())"Belum ada transaksi" else sales.joinToString("\n\n"){ "${java.text.SimpleDateFormat("dd/MM/yyyy HH:mm",Locale("id")).format(java.util.Date(it.time))}\n${money(it.total)}"}).setPositiveButton("OK",null).show()}}
}
data class CartItem(val name:String,val priceKg:Double,val grams:Double,val barcode:String)
