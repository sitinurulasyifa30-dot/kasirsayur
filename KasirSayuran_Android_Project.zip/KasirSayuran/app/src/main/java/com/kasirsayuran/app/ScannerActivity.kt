package com.kasirsayuran.app
import android.app.Activity
import android.os.Bundle
import com.journeyapps.barcodescanner.CaptureActivity
import com.journeyapps.barcodescanner.IntentIntegrator
import com.journeyapps.barcodescanner.IntentResult
class ScannerActivity:CaptureActivity(){
 override fun onCreate(b:Bundle?){super.onCreate(b); IntentIntegrator(this).apply{setPrompt("Arahkan kamera ke barcode");setBeepEnabled(true);setOrientationLocked(true);setCaptureActivity(ScannerActivity::class.java)}.initiateScan()}
 override fun onActivityResult(r:Int,c:Int,d:android.content.Intent?){val res:IntentResult?=IntentIntegrator.parseActivityResult(r,c,d);if(res!=null){if(res.contents!=null)setResult(Activity.RESULT_OK,android.content.Intent().putExtra("barcode",res.contents));else setResult(Activity.RESULT_CANCELED);finish()}else super.onActivityResult(r,c,d)}
}
