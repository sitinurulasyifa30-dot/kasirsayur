package com.kasirsayuran.app
import android.content.Context
import androidx.room.*
@Entity(tableName="products",indices=[Index(value=["barcode"],unique=true)]) data class Product(@PrimaryKey(autoGenerate=true) val id:Int=0,val name:String,val barcode:String,val priceKg:Double,val stockKg:Double)
@Entity(tableName="sales") data class Sale(@PrimaryKey(autoGenerate=true) val id:Int=0,val time:Long,val total:Double)
@Dao interface ProductDao{ @Query("SELECT * FROM products WHERE barcode=:code LIMIT 1") suspend fun byBarcode(code:String):Product?; @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun insert(p:Product) }
@Dao interface SaleDao{ @Query("SELECT * FROM sales ORDER BY time DESC") suspend fun all():List<Sale>; @Insert suspend fun insert(s:Sale) }
@Database(entities=[Product::class,Sale::class],version=1) abstract class AppDb:RoomDatabase(){abstract fun productDao():ProductDao;abstract fun saleDao():SaleDao;companion object{private var x:AppDb?=null;fun get(c:Context)=x?:Room.databaseBuilder(c.applicationContext,AppDb::class.java,"kasir_sayuran.db").fallbackToDestructiveMigration().build().also{x=it}}}
